$('#language').on('change', function() {
  var lang = $(this).val();
  $.ajax({
    url: '/translate/' + lang,
    type: 'GET',
    success: function(data) {
      // Replace content on the page with the translated data
      $('#content').html(data);
    },
    error: function() {
      console.log('Failed to load translation');
    }
  });
});
app.get('/translate/:lang', function(req, res) {
  var lang = req.params.lang;
  // Fetch translated content based on the language
  var translatedContent = translate(lang);
  res.send(translatedContent);
});

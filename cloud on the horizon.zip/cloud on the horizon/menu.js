$(document).ready(function() {
    // add click event handler to the "Menu" button
    $("#menu").click(function() {
        // create a heading for the menu and apply a CSS style to increase the font size
        var menuHeading = $("<h2>").text("In house MENU today").attr("id", "menu-display");
        
        // create an unordered list to hold the menu items
        
        var menuList = $("<ul>").attr("id", "menu-list");



        // add menu items to the list
        menuList.append($("<li>").addClass("menu-item").attr("id", "beer-display").html("<img src='beer.jpeg' alt='Beer' class='menu-img' id='beer-img'>Beer"));
        menuList.append($("<li>").addClass("menu-item").attr("id", "cocktails-display").html("<img src='cocktail.jpeg' alt='Cocktail/Drinks' class='menu-img'>Cocktail/Drinks"));
        menuList.append($("<li>").addClass("menu-item").attr("id", "wine-display").html("<img src='wine.jpeg' alt='Wine' class='menu-img'>Wine"));
        menuList.append($("<li>").addClass("menu-item").attr("id", "tgif-display").html("<img src='tgif.jpeg' alt='TGIF' class='menu-img'>TGIF"));

        // add the heading and menu list to the main container
        $("#menu_container").empty().append(menuHeading, menuList);
    });
});

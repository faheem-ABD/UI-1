//wine

var bvTypes = beverageTypes();
var dryvineTypes = bvTypes.filter(type =>type.includes("Vitt torrt")); 
var redvineTypes = bvTypes.filter(type =>type.includes("RÃ¶tt vin")); 
var whitevineTypes = bvTypes.filter(type =>type.includes("Vitt vin"));  

// Get the div element
var container = document.getElementById("menu_item");


var beverages = allBeverages();

var allVinesInTheMenu = []

//dry wine
var allDryvineDrinks = [];

beverages.forEach(b => {
    dryvineTypes.forEach(wt => {
        if(wt === b.group) {
            allDryvineDrinks.push(b);
        }
    });
});

//red wine
var allRedvineDrinks = [];

beverages.forEach(b => {
    redvineTypes.forEach(wt => {
        if(wt === b.group) {
            allRedvineDrinks.push(b);
        }
    });
});


//white wine
var allWhitevineDrinks = [];

beverages.forEach(b => {
    whitevineTypes.forEach(wt => {
        if(wt === b.group) {
            allWhitevineDrinks.push(b);
        }
    });
});


//Vine
allVinesInTheMenu.push(...allDryvineDrinks.splice(0,5), ...allRedvineDrinks.splice(0,5), ...allWhitevineDrinks.splice(0,5));

allVinesInTheMenu.forEach(item => {

var newVineContainer = document.createElement("div");
const img = document.createElement('img');
img.src = 'assets/images/wine.png';

img.classList.add("drink-img")


// Create a new element
var vinePrice = document.createElement("p");
// Add some content to the new element
vinePrice.textContent = `${item.price} kr`;

// Set the color and font weight of the vine price
vinePrice.style.color = "red";
vinePrice.style.fontWeight = "bold";

// Create a new element
var vineName = document.createElement("p");
// Add some content to the new element
vineName.textContent = item.name;

// Create a new element
var alcoholContent = document.createElement("p");
// Add some content to the new element
alcoholContent.textContent = item.alcoholContent;


// Appending everything in the new beer container
newVineContainer.appendChild(img);
newVineContainer.appendChild(vineName);
newVineContainer.appendChild(alcoholContent);
newVineContainer.appendChild(vinePrice);

newVineContainer.classList.add("drink-container")
giveDragAbility(newVineContainer)




// Append the new element to the div
container.appendChild(newVineContainer);

})
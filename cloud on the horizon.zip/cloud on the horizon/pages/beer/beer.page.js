//beer
var bvTypes = beverageTypes();
var aleTypes = bvTypes.filter(type =>type.includes("Ale")); 
var lagerTypes = bvTypes.filter(type =>type.includes("Ljus lager")); 
var stoutTypes = bvTypes.filter(type =>type.includes("Porter och Stout"));  

// Get the div element
var container = document.getElementById("menu_item");


var beverages = allBeverages();

var allBeersInTheMenu = []


//beer
var allAleDrinks = [];

beverages.forEach(b => {
    aleTypes.forEach(wt => {
        if(wt === b.group) {
            allAleDrinks.push(b);
        }
    });
});

//beer
var allLagerDrinks = [];

beverages.forEach(b => {
    lagerTypes.forEach(wt => {
        if(wt === b.group) {
            allLagerDrinks.push(b);
        }
    });
});

//beer
var allStoutDrinks = [];

beverages.forEach(b => {
    stoutTypes.forEach(wt => {
        if(wt === b.group) {
            allStoutDrinks.push(b);
        }
    });
});

//beer
allBeersInTheMenu.push(...allAleDrinks.splice(0,5), ...allLagerDrinks.splice(0,5), ...allStoutDrinks.splice(0,5));

allBeersInTheMenu.forEach(item => {

var newBeerContainer = document.createElement("div");
const img = document.createElement('img');
img.src = 'assets/images/beer.png';

img.classList.add("drink-img")


// Create a new element
var beerPrice = document.createElement("p");
// Add some content to the new element
beerPrice.textContent = `${item.price} kr`;

// Set the color and font weight of the beer price
beerPrice.style.color = "red";
beerPrice.style.fontWeight = "bold";

// Create a new element
var beerName = document.createElement("p");
// Add some content to the new element
beerName.textContent = item.name;

// Create a new element
var beerId = document.createElement("p");
// Add some content to the new element
beerId.textContent = item.id;

// Create a new element
var alcoholContent = document.createElement("p");
// Add some content to the new element
alcoholContent.textContent = item.alcoholContent;


// Appending everything in the new beer container
newBeerContainer.appendChild(img);
newBeerContainer.appendChild(beerId);
newBeerContainer.appendChild(beerName);
newBeerContainer.appendChild(alcoholContent);
newBeerContainer.appendChild(beerPrice);

newBeerContainer.classList.add("drink-container")
giveDragAbility(newBeerContainer);
newBeerContainer.addEventListener('click', place_drink_to_order)



// Append the new element to the div
container.appendChild(newBeerContainer);

})


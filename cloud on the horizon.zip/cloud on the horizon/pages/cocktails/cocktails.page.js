//cocktails and cider

var bvTypes = beverageTypes();
var otherTypes = bvTypes.filter(type =>type.includes("Flera type")); 
var ciderTypes = bvTypes.filter(type =>type.includes("Cider")); 
var mixedTypes = bvTypes.filter(type =>type.includes("Blanddrycker")); 

// Get the div element
var container = document.getElementById("menu_item");


var beverages = allBeverages();

var allCocktailsInTheMenu = []

//otherDrinks

var allOtherDrinks = [];
beverages.forEach(b => {
    otherTypes.forEach(wt => {
        if(wt === b.group) {
            allOtherDrinks.push(b);
        }
    });
});

//cider
var allCiderDrinks = [];

beverages.forEach(b => {
    ciderTypes.forEach(wt => {
        if(wt === b.group) {
            allCiderDrinks.push(b);
        }
    });
});


//cider
var allMixedDrinks = [];

beverages.forEach(b => {
    mixedTypes.forEach(wt => {
        if(wt === b.group) {
            allMixedDrinks.push(b);
        }
    });
});


allCocktailsInTheMenu.push(...allCiderDrinks.splice(0,5), ...allMixedDrinks.splice(0,5), ...allOtherDrinks.splice(0,5));

allCocktailsInTheMenu.forEach(item => {

var newCocktailsContainer = document.createElement("div");
const img = document.createElement('img');
img.src = 'assets/images/cocktails.png';

img.classList.add("drink-img")


// Create a new element
var cocktailsPrice = document.createElement("p");
// Add some content to the new element
cocktailsPrice.textContent = `${item.price} kr`;

// Set the color and font weight of the beer price
cocktailsPrice.style.color = "red";
cocktailsPrice.style.fontWeight = "bold";

// Create a new element
var cocktailsName = document.createElement("p");
// Add some content to the new element
cocktailsName.textContent = item.name;

// Create a new element
var alcoholContent = document.createElement("p");
// Add some content to the new element
alcoholContent.textContent = item.alcoholContent;


// Appending everything in the new beer container
newCocktailsContainer.appendChild(img);
newCocktailsContainer.appendChild(cocktailsName);
newCocktailsContainer.appendChild(alcoholContent);
newCocktailsContainer.appendChild(cocktailsPrice);

newCocktailsContainer.classList.add("drink-container")
giveDragAbility(newCocktailsContainer)




// Append the new element to the div
container.appendChild(newCocktailsContainer);

})
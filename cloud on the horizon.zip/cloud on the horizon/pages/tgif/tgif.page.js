//TGIF
var bvTypes = beverageTypes();
var whiskyTypes = bvTypes.filter(type =>type.includes("Whisky"));
var tequilaTypes = bvTypes.filter(type =>type.includes("Tequila"));
var ginTypes = bvTypes.filter(type =>type.includes("Gin"));

// Get the div element
var container = document.getElementById("menu_item");


var beverages = allBeverages();

var allTgifsInTheMenu = []

// var allWhiskyBeverages = beverages.filter(beverage => whisky.forEach(element => beverage.includes(element)).includes(beverage));

// beverages.forEach(b => console.log(b));
var allWhiskyDrinks = [];

beverages.forEach(b => {
    whiskyTypes.forEach(wt => {
        if(wt === b.group) {
            allWhiskyDrinks.push(b);
        }
    });
});

var allTequilaDrinks = [];

beverages.forEach(b => {
    tequilaTypes.forEach(wt => {
        if(wt === b.group) {
            allTequilaDrinks.push(b);
        }
    });
});

var allGinDrinks = [];

beverages.forEach(b => {
    ginTypes.forEach(wt => {
        if(wt === b.group) {
            allGinDrinks.push(b);
        }
    });
});



//Tgif
allTgifsInTheMenu.push(...allGinDrinks.splice(0,5), ...allTequilaDrinks.splice(0,5), ...allWhiskyDrinks.splice(0,5));

allTgifsInTheMenu.forEach(item => {

var newTgifContainer = document.createElement("div");
const img = document.createElement('img');
img.src = 'assets/images/tgif.png';

img.classList.add("drink-img")


// Create a new element
var tgifPrice = document.createElement("p");
// Add some content to the new element
tgifPrice.textContent = `${item.price} kr`;

// Set the color and font weight of the beer price
tgifPrice.style.color = "red";
tgifPrice.style.fontWeight = "bold";

// Create a new element
var tgifName = document.createElement("p");
// Add some content to the new element
tgifName.textContent = item.name;

// Create a new element
var alcoholContent = document.createElement("p");
// Add some content to the new element
alcoholContent.textContent = item.alcoholContent;


// Appending everything in the new beer container
newTgifContainer.appendChild(img);
newTgifContainer.appendChild(tgifName);
newTgifContainer.appendChild(alcoholContent);
newTgifContainer.appendChild(tgifPrice);

newTgifContainer.classList.add("drink-container")
giveDragAbility(newTgifContainer)





// Append the new element to the div
container.appendChild(newTgifContainer);

})

 // GLOBAL VARIABLES
 let orderTotal;
 let order = {};
 let current_balance;
 let current_user;

 var curr_order =[];


//  <!-- DATA VARIABLES FROM DATAFILES -->
 let users = DB.users;
 let transactions = DB.sold;
 let balances = DB.account;
 let credentials_dict = {"0" : "Manager", "1" : "Bartender",
                     "2" : "Waiter", "3" : "VIP Guest", "4" : "Guest"};

$(function() {
    update_view();
    // LOGIN FUNCTION -------------------------------------------------------------------
    $('#show-login-popup-button').on("click", function() {
      // SHOW THE LOGIN POPUP FORM
      $('#login-popup').show();
      show_login_popup();
    });
  
    // BUTTON FOR DEPOSITING MONEY ------------------------------------------------------
    $('#deposit-button').on("click", function() {
      // SHOW THE DEPOSIT POPUP FORM
      $('#popup').show();
      show_deposit_popup();
    });

    $('#deposit-popup-button').on('click', function() {
        let deposit_amount = $('#number-input').val();
            current_balance = (Number(current_balance) + Number(deposit_amount)).toString();
    })
  
    // CATEGORY BUTTONS ------------------------------------------------------------------
    let categoryButtons = $('.menu-category');
    categoryButtons.on("click", function() {
      choose_category_function(this.id);
    });


$(document).ready(function() {

    // Code to run after the DOM is initialized
    var menu = document.querySelector(".app-bar");
    var menuItems = menu.querySelectorAll("a");
    var menuContainer = $("#menu_container");
    var beverages = allBeverages();
    navigationInitialization(menuContainer);

     // Initialize an empty array to keep track of changes
     var history = [];
     var index = -1;
     
     // Add a change event listener to the menu container
     menuContainer.on("change", function() {
         // Add the current state to the history
         history.splice(index + 1, history.length - index - 1);
         history.push(menuContainer.html());
         index++;
     });
     
     // Add a click event listener to the undo button
     $("#undoButton").on("click", function() {
         if (index > 0) {
             index--;
             menuContainer.html(history[index]);
         }
     });
     
     // Add a click event listener to the redo button
     $("#redoButton").on("click", function() {
         if (index < history.length - 1) {
             index++;
             menuContainer.html(history[index]);
         }
     });
      
    $(".app-bar a").on("click", function(event) {
        // Code to run when the button is clicked
        event.target.classList.add("active");
        for (let i = 0; i < menuItems.length; i++) {
            if(event.target.id === menuItems[i].id ) {
                continue;
            }
            const child = menuItems[i];
            // Do something with each child element
            child.classList.remove("active");
          }
    });

});


function navigationInitialization(menuContainer) {
    
    $("#beer").on("click", function(event) {
        // call and add another html page in the main container
        menuContainer.load("./pages/beer/beer-page.html")
    });
    
    $("#wine").on("click", function(event) {
        // call and add another html page in the main container
        menuContainer.load("./pages/wine-page/wine-page.html")
    });
    
    $("#cocktails-drinks").on("click", function(event) {
        // call and add another html page in the main container
        menuContainer.load("./pages/cocktails/cocktails-page.html")
    });
    
    $("#tgif").on("click", function(event) {
        // call and add another html page in the main container
        menuContainer.load("./pages/tgif/tgif-page.html")
    });
    
    $("#alert").on("click", function(event) {
        // call and add another html page in the main container
        menuContainer.load("./pages/alert-page/alert.html")
    });
}
if (typeof update_view === "function") {
    update_view();
  }
});


// A functiomn to placre_order

function place_drink_to_order(to_order){
    var old_order = [...curr_order];
    doit(place_order_redo(to_order,old_order))
}

function place_order_redo(order, old) {
    var tempFunObject = {

        // arguments
        //
        to_order: order,      // BeerName
        old_order: old,

        // replace function body
        //
        execute: function () {      // The original action
            if ( curr_order.length < 10) {
                curr_order.push(this.to_order);
            }
            else{
                // Temporary
                console.log("To many orders")
            }
        },

        unexecute: function () {    // Undoing the action
            //  Deep copy
            //
            curr_order = [...this.old_order];
            console.log(this.old_order)
        },

        reexecute: function () {    // Redoing the action is the same as doing it
            // the first time.
            if ( curr_order.length < 10) {
                curr_order.push(this.to_order);
            }
            else{
                // Temporary
                console.log("To many orders")
            }
        }
    }
    return tempFunObject;
}

function remove_drink_in_order(to_remove){
    // Use Spread operator (deep copy)
    var old_order = [...curr_order];
    doit(remove_order_redo(to_remove, old_order));
}

// ==========================================================================
// Function to remove orders
// order - name of the drink to remove from the order
// old - the state of the order before removing the drink
// Uses undo/redo mechanism provided in the course material
// Returns function object which is used by the undo/redo mechanism
//
function remove_order_redo(order, old){
    var tempFunObject = {
        // arguments
        //
        to_remove: order,      // BeerName
        old_order: old,

        // replace function body
        //
        execute: function () {      // The original action
            var index = 0;
            for(i = 0; i < curr_order.length; i++){
                console.log(this.to_remove[0])
                console.log(curr_order[i][0])
                if (curr_order[i][0] == this.to_remove[0]){
                    index = i;
                }
            }
            if(index != -1){
                curr_order.splice(index, 1);
            }
        },

        unexecute: function () {    // Undoing the action
            //  Deep copy
            //
            curr_order = [...this.old_order];
            console.log(this.old_order)
        },

        reexecute: function () {    // Redoing the action is the same as doing it
            // the first time.
            var index = 0;
            for(i = 0; i < curr_order.length; i++){
                console.log(this.to_remove[0])
                console.log(curr_order[i][0])
                if (curr_order[i][0] == this.to_remove[0]){
                    index = i;
                }
            }
            if(index != -1){
                curr_order.splice(index, 1);
            }
        }
    }
    return tempFunObject;
}










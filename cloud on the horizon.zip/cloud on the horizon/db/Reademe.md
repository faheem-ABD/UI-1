# To run the program

Load the files in a Vscode and install the live server snippet and press the port button (GoLive) to make the server run dynamically on a website


# Login
Username: jovsit
Password: 1fcb15df01a8ca6a442058aca336b324

# 

# Group work distribution 
Faheem : Mostly focus HTML and Responsive Design where used CSS also payment part
Shani : Some portion of controller and Drag and Drop  portion
Fatama:Focus on Multilingual interfaces  and also contribute on view part for CSS, contributed on VIP customer pages
Fatama, faheem and Shani : all work on Model part to focus on database.

# Remaining part

Not working: Undo-Redo works sometimes
Manager page and the bartender page is not working , so its hard to change the stock room
Special order can be sent as comment and not as separate page
Splitting the bill option has not been implemented

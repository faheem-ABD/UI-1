// ==========================================================================
// We need to have a variable that controls which language to use.
// In this file we only show the simplest version of language change.
// How to do this with more than two languages, is left as an
// exercise.
//

let language = 'en';

// ==========================================================================
// The dictionary consists of a simple JSON structure. It also keeps
// track of the different keys that are available  for IDs.
//
dict = {
    // keys for strings
    'keys' :
        ['guest-mode-text',
            'show-login-popup-button',
            'menu-header',
            'username-label',
            'password-label',
            'login-button',
            'login_as_guest',
            'credit-label',
            'deposit-button',
            'logout-button',
            'deposit-popup-label',
            'deposit-popup-button',
            'current-order-label',
            'empty-order-message',
            'thank-you-order-message',
            'order-button',
            'order-total-label',
            'comment-popup-label',
            'comment-submit',
            'menu',
            'beer',
            'cocktails-drinks',
            'beer-drinks',
            'wine',
            'alert',
            'tgif',
            'Undo',
            'Redo',
            'menu-display',
            'call-cops-heading',
            'beer-menu-heading',
            'cocktails-menu',
            'tgif-menu',
            'wine-menu',
            'beer-display',
            'wine-display',
            'cocktails-display'

            

            
    ],

    // We use one JSON substructure for each language. If we have
    // many different languages and a large set of strings we might
    // need to store a JSON file for each language to be loaded on
    // request.
    //
    'en': {
        'guest-mode-text' : "You are in guest mode.",
        'show-login-popup-button': "Press to login",
        'menu-header' : 'Menu',
        'username-label' : 'Username:',
        'password-label' : 'Password:',
        'login-button' : 'Login',
        'login_as_guest' : 'Continue as guest',
        'credit-label' : 'Balance: ', //Include space at the end
        'deposit-button' : 'Deposit money',
        'logout-button' : 'Logout',
        'deposit-popup-label' : 'Enter amount to add:',
        'deposit-popup-button' : 'Add to balance',
        'current-order-label' : 'Current Order',
        'empty-order-message' : 'Your order is empty',
        'thank-you-order-message' : 'Thank you for your order',
        'order-button' : 'Place order',
        'order-total-label' : 'Total: ', //Include space at the end
        'comment-popup-label' : 'Add comment to ', //Include space at the end
        'comment-submit' : 'Add comment',
        'menu' : 'menu',
        'beer': 'beer',
        'cocktails-drinks' : 'cocktails/drinks',
        'beer-drinks': 'beer/drinks',
        'wine' : 'wine',
        'alert': 'alert',
        'tgif' : 'tgif' ,
        'Undo' : 'undo' ,
        'Redo' : 'redo',
        'call-cops-heading' : 'Call the Cops !!!!!!!!!'
        
        
        

        

    },

    // Fill with Swedish Translation
    'sv' : {
        'guest-mode-text' : "Du tittar som gäst.",
        'show-login-popup-button' : "Logga in",
        'menu-header' : 'Meny',
        'username-label' : 'Användarnamn:',
        'password-label' : 'Lösenord:',
        'login-button' : 'Logga in',
        'login_as_guest' : 'Fortsätt som gäst',
        'credit-label' : 'Saldo: ', //Include space at the end
        'deposit-button' : 'Lägg in pengar',
        'logout-button' : 'Logga ut',
        'deposit-popup-label' : 'Ange belopp',
        'deposit-popup-button' : 'Lägg till',
        'current-order-label' : 'Din beställning',
        'empty-order-message' : 'Din beställning är tom',
        'thank-you-order-message' : 'Tack för din beställning',
        'order-button' : 'Beställ',
        'order-total-label' : 'Summa: ', //Include space at the end
        'comment-popup-label' : 'Lägg till kommentar för ', //Include space at the end
        'comment-submit' : 'Lägg till kommentar',
        'menu' : 'meny',
        'beer': 'öl',
        'cocktails-drinks' : 'cocktails/drinkar',
        'wine' : 'vin',
        'alert': 'varna',
        'tgif' : 'tgif' ,
        'Undo' : 'ångra' ,
        'Redo' : 'göra om',
        'menu-display' : 'På menyn idag',
        'call-cops-heading' : 'ring polisen',
        'beer-menu-heading' : 'öl Meny',
        'cocktails-menu' : 'Cocktails Meny',
        'tgif-menu' : 'TGIF Meny',
        'wine-menu' : 'Vin Meny',
        'beer-display': 'öL',
        'wine-display' : 'Vin'
        
        
    },
    // FILL WITH Swahiti TRANSLATION
    'swh': {
        'guest-mode-text' : "Uko katika hali ya wageni.",
        'show-login-popup-button': "Bonyeza ili kuingia",
        'menu-header' : 'Menyu',
        'username-label' : 'Jina la mtumiaji:',
        'password-label' : 'Nenosiri:',
        'login-button' : 'Ingia',
        'login_as_guest' : 'Endelea kama mgeni',
        'credit-label' : 'Mizani: ', //Include space at the end
        'deposit-button' : 'Weka pesa',
        'logout-button' : 'Ondoka',
        'deposit-popup-label' : 'Weka kiasi cha kuongeza:',
        'deposit-popup-button' : 'Ongeza kwa usawa',
        'current-order-label' : 'Agizo la Sasa',
        'empty-order-message' : 'Agizo lako ni tupu',
        'thank-you-order-message' : 'Asante kwa agizo lako',
        'order-button' : 'Agiza',
        'order-total-label' : 'Jumla: ', //Include space at the end
        'comment-popup-label' : 'Ongeza maoni kwa ', //Include space at the end
        'comment-submit' : 'Ongeza maoni',
        'menu' : 'menyu',
        'beer': 'bia',
        'cocktails-drinks' : 'cocktails/vinywaji',
        'wine' : 'mvinyo',
        'alert': 'tahadhari',
        'tgif' : 'tgif' ,
        'Undo' : 'tengua' ,
        'Redo' : 'rudia',
        'menu-display' : 'Kwenye menyu ya leo',
        'call-cops-heading' : 'Ita polisi',
        'beer-menu-heading' : 'Bia Menuy',
        'cocktails-menu' : 'Cocktails Menyu',
        'tgif-menu' : 'TGIF Menyu',
        'wine-menu' : 'Mvinyo Menyu',
        'beer-display': 'Bia',
        'wine-display' : 'Mvinyo'
        
        
        
    },
    // FILL WITH GERMAN TRANSLATION
    'de': {
        'guest-mode-text' : "Sie befinden sich im Gastmodus.",
        'show-login-popup-button': "Drücken Sie um sich anzumelden",
        'menu-header' : 'Speisekarte',
        'username-label' : 'Nutzername:',
        'password-label' : 'Passwort:',
        'login-button' : 'Anmeldung',
        'login_as_guest' : 'Als Gast fortfahren',
        'credit-label' : 'Gleichgewicht: ', 
        'deposit-button' : 'Geld einzahlen',
        'logout-button' : 'Logout',
        'deposit-popup-label' : 'Geben Sie den hinzuzufügenden Betrag ein:',
        'deposit-popup-button' : 'Zum Guthaben hinzufügen',
        'current-order-label' : 'Aktueller Auftrag',
        'empty-order-message' : 'Ihre Bestellung ist leer',
        'thank-you-order-message' : 'Vielen Dank für Ihre Bestellung',
        'order-button' : 'Bestellung aufgeben',
        'order-total-label' : 'Gesamt: ', 
        'comment-popup-label' : 'Einen Kommentar hinzufügen ', 
        'comment-submit' : 'Einen Kommentar',
        'menu' : 'Speisekarte',
        'beer': 'Bier',
        'cocktails-drinks' : 'cocktails/Getränke',
        'wine' : 'Wein',
        'alert': 'Alarm',
        'tgif' : 'tgif' ,
        'Undo' : 'rückgängig machen' ,
        'Redo' : 'wiederholen',
        'menu-display' : 'Heute auf der Speisekarte',
        'call-cops-heading' : 'Ruf die Polizei',
        'beer-menu-heading' : 'Bier Speisekarte',
        'cocktails-menu' : 'Cocktails Speisekarte',
        'tgif-menu' : 'TGIF Speisekarte',
        'wine-menu' : 'Wein Speisekarte',
        'beer-display': 'Bier',
        'wine-display' : 'Wein'
        
       
    },
}

// This function will return the appropriate string for each
// key. The language handling is made "automatic".
//
function get_string(key) {
    return dict[language][key];
}

// This function is the simplest possible. However, in order
// to handle many different languages it will not be sufficient.
// The necessary change should not be difficult to implement.
//
// After each language change, we will need to update the view, to propagate
// the change to the whole view.
//

function update_view() {
    let keys = dict['keys'];
    for (let idx in keys) {
        let key = keys[idx];
        $("#" + key).text(get_string(key));
    };
    let pics = dict['pics'];
    for (let idx in pics) {
        let pic = pics[idx];
        $("#" + pic).attr('src', get_string(pic));
    };
}

function change_lang(lang) {
    language = lang;
    update_view();
}

// ==========================================================================
// END OF FILE
// ==========================================================================


// Get the drag and drop elements
let dragElement;
let orderContainer;
var beverages = allBeverages();

function giveDragAbility(element) {
    element.draggable = true;   
    
    element.addEventListener("dragstart", dragStart);
}


$(document).ready(function() {
    orderContainer = document.getElementById("order_container");
    
    // Add event listeners for the drag and drop events
    orderContainer.addEventListener("dragenter", dragEnter);
    orderContainer.addEventListener("dragover", dragOver);
    orderContainer.addEventListener("dragleave", dragLeave);
    orderContainer.addEventListener("drop", drop);
})

// Define the drag event handlers
function dragStart(event) {
  // Set the drag data (you can customize this to your needs)
  event.dataTransfer.setData("text/plain", event.target.innerHTML);
}

function dragEnter(event) {
  // Add a class to the drop zone to indicate a potential drop
  event.preventDefault();
  dropZone.classList.add("dragover");
}

function dragOver(event) {
  // Allow the drop to occur
  event.preventDefault();
}

function dragLeave(event) {
  // Remove the class from the drop zone
  dropZone.classList.remove("dragover");
}

function drop(event) {
  // Get the dropped data and add it to the order container
  event.preventDefault();
  const data = event.dataTransfer.getData("text/plain");

  // Create a new HTML element to add to the order container
  const newOrderItem = document.createElement("div");
  newOrderItem.classList.add("my-class")
  newOrderItem.innerHTML = data;

  // Add the new element to the order container
  orderContainer.append(newOrderItem);
  beverages.forEach(beverage => {
    if(beverage.id === orderContainer.children[0].children[1].innerHTML.trim()) {
      add_to_order(beverage)
      // console.log(orderContainer.children[0].children[1].innerHTML.trim());
    }
  });

  // Remove the class from the drop zone
  dropZone.classList.remove("dragover");
}
